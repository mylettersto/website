<h3 class="qode-course-single-title">
	<?php the_title(); ?>
</h3>