<h4 itemprop="name" class="qode-name entry-title">
	<?php the_title(); ?>
</h4>