<?php

include_once QODE_RESTAURANT_ABS_PATH . '/modules/widgets/working-hours/working-hours.php';
include_once QODE_RESTAURANT_ABS_PATH . '/modules/widgets/working-hours/functions.php';