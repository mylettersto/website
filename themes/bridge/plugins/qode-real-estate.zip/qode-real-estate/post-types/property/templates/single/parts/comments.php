<?php if(bridge_qode_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>