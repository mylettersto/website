<a class="qodef-re-add-to-compare" href="javascript:void(0)" title="<?php esc_attr_e('Compare property', 'qode-real-estate') ?>" data-item-id="<?php echo esc_attr($item_id); ?>">
    <span class="qodef-re-add-to-compare-text"><?php echo esc_html($item_text); ?></span>
</a>