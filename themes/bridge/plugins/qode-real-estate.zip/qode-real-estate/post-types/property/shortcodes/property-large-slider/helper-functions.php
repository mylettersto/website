<?php
if(!function_exists('qodef_re_property_large_slider_shortcode_helper')) {
    function qodef_re_property_large_slider_shortcode_helper($shortcodes_class_name) {
        $shortcodes = array(
            'QodefRE\CPT\Shortcodes\Property\PropertyLargeSlider'
        );

        $shortcodes_class_name = array_merge($shortcodes_class_name, $shortcodes);

        return $shortcodes_class_name;
    }

    add_filter('qodef_re_filter_add_vc_shortcode', 'qodef_re_property_large_slider_shortcode_helper');
}

if( !function_exists('qodef_re_set_property_large_slider_icon_class_name_for_vc_shortcodes') ) {
    /**
     * Function that set custom icon class name for property large slider shortcode to set our icon for Visual Composer shortcodes panel
     */
    function qodef_re_set_property_large_slider_icon_class_name_for_vc_shortcodes($shortcodes_icon_class_array) {
        $shortcodes_icon_class_array[] = '.icon-wpb-property-large-slider';

        return $shortcodes_icon_class_array;
    }

    add_filter('qodef_re_filter_add_vc_shortcodes_custom_icon_class', 'qodef_re_set_property_large_slider_icon_class_name_for_vc_shortcodes');
}

if(!function_exists('qodef_re_include_elementor_property_large_slider_shortcode')) {
	function qodef_re_include_elementor_property_large_slider_shortcode() {
		include_once QODE_RE_CPT_PATH.'/property/shortcodes/property-large-slider/elementor-property-large-slider.php';
	}

	add_action('bridge_core_load_elementor_shortcodes_from_plugins', 'qodef_re_include_elementor_property_large_slider_shortcode');
}

if( ! function_exists( 'qodef_re_include_property_large_slider_shortcode_for_owl_carousel' ) ) {
	function qodef_re_include_property_large_slider_shortcode_for_owl_carousel( $shortcodes_to_check ) {
		$shortcodes_to_check[] = 'qodef_property_large_slider';
		
		return $shortcodes_to_check;
	}
	
	add_filter( 'bridge_qode_filter_owl_carousel_shortcodes', 'qodef_re_include_property_large_slider_shortcode_for_owl_carousel' );
}