<?php
include_once BRIDGE_CORE_SHORTCODES_PATH.'/sliding-image-holder/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/sliding-image-holder/sliding-image-holder.php';