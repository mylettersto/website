<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_message/message.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_message/custom-styles/custom-styles.php';
