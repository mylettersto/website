<p class="qode-pl-not-found">
	<?php esc_html_e( 'Sorry, no posts matched your criteria.', 'qode-listing' );?>
</p>