<?php

include_once 'lib/qode-twitter-api.php';
include_once 'widgets/load.php';
require_once 'shortcodes/qode-twitter-feed.php';
include_once 'shortcodes/load.php';