<?php

include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/functions.php';
include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/reset-password/reset-password.php';